package person_language_xml.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import person_language_xml.dao.PersonDao;
import person_language_xml.dto.Language;
import person_language_xml.dto.Person;

public class PersonDriver {
   public static void main(String[] args) {
	  
	  
	   		ApplicationContext context = new ClassPathXmlApplicationContext("person.xml");
//	   	Person person = context.getBean("p", Person.class);
	   	Person person1 = context.getBean("p1", Person.class);
	   	Person person2 = context.getBean("p2", Person.class);
	   	
	   	//	person.info();
	   		PersonDao dao = context.getBean("dao", PersonDao.class);
		//	   	    dao.savePerson(person1);
//	   	    dao.savePerson(person2);
//	   	     dao.getPerson(1);
//	   	   dao.updatePerson(25,person1);
//	   	     dao.updateBoth(1,person);
	   	     dao.deletePerson(2);
	   }
	   
}

