package person_language_xml.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import person_language_xml.dto.Language;
import person_language_xml.dto.Person;

public class PersonDao {
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("Anshu");
	EntityManager manager=factory.createEntityManager();
	EntityTransaction transaction=manager.getTransaction();
	public void savePerson(Person person) {
		 List<Language> list=person.getList();
			transaction.begin();
			for(Language language : list) {
				manager.persist(language);
			}
			manager.persist(person);
			transaction.commit();
		}
		
		
		
		public void getPerson(int id) {
		
			Person person=manager.find(Person.class,id);
			if(person !=null) {
				System.out.println(person);
			}
			else
			{
				System.out.println("no person found with id"+id);
			}
		}
		
		
		public void deletePerson(int id) {
			Person person=manager.find(Person.class,id);
			if(person !=null) {
				 List<Language> list=person.getList();
				 transaction.begin();
				 for(Language language : list) {
						manager.remove(language);
					}
					manager.remove(person);
					transaction.commit();
			}
			else
			{
				System.out.println("no person found with id"+id);
			}
		}
		public void updatePerson(int id,Person person) {
			Person person1=manager.find(Person.class,id);
			if(person1 !=null) {
				person1.setId(id);
				person1.setList(person1.getList());
				 transaction.begin();
				 manager.merge(person1);
				 transaction.commit();
		}
			else
			{
				System.out.println("no person found with id"+id);
			}
		}
		public void updateBoth(int id,Person person) {
			Person person2=manager.find(Person.class,id);
			if(person2 !=null) {
				person.setId(id);
				for(int i=0;i<person2.getList().size();i++) {
					person.getList().get(i).setId(person2.getList().get(i).getId());
				}
				 transaction.begin();
				 for(Language language : person.getList()) {
						manager.merge(language);
					}
				 manager.merge(person);
				 transaction.commit();
			}
			else
			{
				System.out.println("no person found with id"+id);
			}
			} 
	
}

